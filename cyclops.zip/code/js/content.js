;(function() {
  console.log('[Cyclops] Running hide YouTube numbers extension')
})()